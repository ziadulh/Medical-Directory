<div class="sidebar app-aside" id="sidebar">
				<div class="sidebar-container perfect-scrollbar">

<nav>
						
						<!-- start: MAIN NAVIGATION MENU -->
						<div class="navbar-title">
							<span>Main Navigation</span>
						</div>
						<ul class="main-navigation-menu">
							<li>
								<a href="dashboard.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-home"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Dashboard </span>
										</div>
									</div>
								</a>
							</li>
							<li>
								<a class="collapsed" data-toggle="collapse" href="#sub-menu">
									<div class="item-content">
										<div class="item-media">
											<i class="fa fa-user-md"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Doctors </span>
											<i class="icon-arrow"></i>
										</div>
									</div>
								</a>
								<ul id="sub-menu">
									<li>
										<a href="add-area.php">
											<span class="title"> Add Area</span>
										</a>
									</li>
									<li>
										<a href="doctor-specilization.php">
											<span class="title">Add Doctor Specialization </span>
										</a>
									</li>
									<li>
										<a href="add-doctor.php">
											<span class="title"> Add Doctor</span>
										</a>
									</li>
									<li>
										<a href="add-hospitals.php">
											<span class="title"> Add Hospitals</span>
										</a>
									</li>
									<li>
										<a href="add-others.php">
											<span class="title"> Add Other Services</span>
										</a>
									</li>
								</ul>
								</li>


<li>
								<a href="appointment-history.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-file"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Appointment History </span>
										</div>
									</div>
								</a>
							</li>

<!-- 							<li>
								<a href="doctor-logs.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-list"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Doctor Session Logs </span>
										</div>
									</div>
								</a>
							</li> -->		



<!-- 							<li>
								<a href="user-logs.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-list"></i>
										</div>
										<div class="item-inner">
											<span class="title"> User Session Logs </span>
										</div>
									</div>
								</a>
							</li> -->						
				

						</ul>
						<!-- end: CORE FEATURES -->
						
					</nav>
					</div>
			</div>